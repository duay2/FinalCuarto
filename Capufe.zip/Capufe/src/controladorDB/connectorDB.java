/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladorDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vagui
 */
public class connectorDB {
    
    private Connection _connection = null;

    public connectorDB() {
        
        String _url = "";
        String _user = "";
        String _password="";
        
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            this._connection = DriverManager.getConnection(_url, _user, _password);
            
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
    
    public Connection getConnection(){
        return this._connection;
    }
    
    public void closeConnection(){
        
        if(this._connection!=null){
            try {
                this._connection.close();
            } catch (SQLException ex) {
                Logger.getLogger(connectorDB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
}
