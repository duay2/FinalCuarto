package entities;

/*
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
*/

/**
 *
 * @author vagui
 */
public class Caseta {
    
    private int id;
    private int tariff = 0;
    private String name = new String();
    private String location = new String();
    
    /*
    public static List<Caseta> getAll(String filtro) {
        List<Caseta> caseta = new ArrayList<>();
        try {
            Connection conexion = MySQLConnection.get();
            PreparedStatement statement = conexion.prepareStatement("SELECT * FROM LV_clientes WHERE name LIKE ?");
            statement.setString(1, "%" + filtro + "%");
            ResultSet resulSet = statement.executeQuery();

            while (resulSet.next()) {
                Caseta c = new Caseta();
                c.setId(resulSet.getInt(1));
                c.setName(resulSet.getString(2));
                c.setTariff(resulSet.getInt(3));
                c.setLocation(resulSet.getString(4));
                caseta.add(c);
            }
        } catch (SQLException ex) {
            System.err.print("Error: " + ex);
        }
        return caseta;
    }
    
    public boolean save(String name, int tariff, String location) {
        boolean result = false;
        try {
            Connection conexion = MySQLConnection.get();
            String query = "INSERT  INTO LV_clientes (nombre, apellido, email) VALUES(?,?,?)";
            PreparedStatement statement= conexion.prepareStatement(query);
            statement.setString(1, name);
            statement.setInt(2, tariff);
            statement.setString(3, location);
            statement.execute();
            
            result = statement.getUpdateCount()==1;
            
            conexion.close();
        } catch (Exception ex) {
            System.err.println("Error "+ex.getMessage());
        }
        return result;
    }
    
    public boolean update(int id, String name, int tariff, String location) {
        boolean result = false;
        try {
            Connection conexion = MySQLConnection.get();
            String query = "UPDATE LV_clientes SET nombre=?, apellido=?, email=? WHERE id=?";
            PreparedStatement statement= conexion.prepareStatement(query);
            statement.setString(1, name);
            statement.setInt(2, tariff);
            statement.setString(3, location);
            statement.setInt(4, id);
            statement.execute();
            
            result = statement.getUpdateCount()==1;
            
            conexion.close();
        } catch (Exception ex) {
            System.err.println("Error "+ex.getMessage());
        }
        return result;
    }
    
    public boolean delete(int id) {
        boolean result = false;
        try {
            Connection conexion = MySQLConnection.get();
            String query = "DELETE FROM LV_clientes WHERE id= ?";
            PreparedStatement statement= conexion.prepareStatement(query);
            statement.setInt(1, id);
            statement.execute();
            
            result = statement.getUpdateCount()==1;
            
            conexion.close();
        } catch (Exception ex) {
            System.err.println("Error "+ex.getMessage());
        }
        return result;
    }
    
    public static Caseta getById(int id) {
        Caseta caseta = null;
        try {
            Connection conexion = MySQLConnection.get();
            String query = "SELECT * FROM LV_peliculas WHERE id = ?";
            PreparedStatement statement = conexion.prepareStatement(query);
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                caseta = new Customer();
                caseta.setId(resultSet.getInt("id"));
                caseta.setName(resultSet.getString("nombre"));
                caseta.setTariff(resultSet.getInt("tarifa"));
                caseta.setLocation(resultSet.getString("ubicacion"));
            }

            conexion.close();
        } catch (SQLException ex) {
            System.err.print("Error: " + ex);
        }
        return caseta;
    }
    */
    
    public Caseta() {
    }

    public int getTariff() {
        return tariff;
    }

    public void setTariff(int tariff) {
        this.tariff = tariff;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
